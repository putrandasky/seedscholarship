<?php $__env->startComponent('mail::layout'); ?>
    
    <?php $__env->slot('header'); ?>
        <?php $__env->startComponent('mail::header', ['url' => config('app.url')]); ?>
            <!-- header here -->
            <img class="img-header" src="<?php echo e(config('app.url').'/images/Seedlogo2.png'); ?>">
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>

    
    <!-- Body here -->


Hai <strong><?php echo e($data->name); ?></strong>,

Kamu telah mendaftar sebagai :
    
<?php $__env->startComponent('mail::panel'); ?>
Calon Awardee untuk SEED Scholarship <strong>#<?php echo e($data->periods[0]->period); ?></strong> untuk tahun <strong><?php echo e($data->periods[0]->year); ?></strong>
<?php echo $__env->renderComponent(); ?>

Berikut detail data yang sudah kamu registrasi ke kami
<?php $__env->startComponent('mail::panel'); ?>
Nama : <?php echo e($data->name); ?><br/>
Email : <?php echo e($data->email); ?><br/>
Phone : <?php echo e($data->phone); ?><br/>
Angkatan : <?php echo e($data->year); ?><br/>
Department : <?php echo e($data->awardeeDepartment->department); ?><br/>
<?php echo $__env->renderComponent(); ?>

Segera siapkan file berikut ini :
<?php $__env->startComponent('mail::panel'); ?>
<ol>
<li>CV / Riwayat Hidup : format bebas dengan informasi yang wajib ada yaitu: data diri, riwayat pendidikan, kemampuan bahasa, pengalaman kerja,
status pekerjaan/pendidikan anggota keluarga</li>
<li>Esai : dengan topik "Mengapa saya pantas mendapatkan beasiswa SEED" sebanyak 300-500 kata</li>
<li>Slip gaji Orang tua / Rekening Listring</li>
<li>SiakNG : Printout Halaman ringkasan dan riwayat</li>
</ol>
<?php echo $__env->renderComponent(); ?>

Selanjutnya upload file tersebut dengan menekan tombol dibawah ini
<?php $__env->startComponent('mail::button', ['url' => config('app.url')."/awardee#/register/upload?id={$data->id}&email={$data->email}&period_id={$data->periods[0]->id}&registration_code={$data->periods[0]->pivot->registration_code}"]); ?>
Upload Disini
<?php echo $__env->renderComponent(); ?>


Segera setelah kamu upload semua file yang dibutuhkan, tim kami akan menghubungi kamu untuk melakukan wawancara.

Terimakasih,<br/>

<br/>
<img style="height:5%" src="<?php echo e(config('app.url').'/images/heart.png'); ?>">
<strong>seedscholarship.org</strong>

    
    <?php $__env->slot('footer'); ?>
        <?php $__env->startComponent('mail::footer'); ?>
            <!-- footer here -->

Anggit Cahyo S’08 : 085697274479 |
Janitra Hendra L’08 : 081290001300
<br/>
Bentuk kontribusi alumni Departemen Teknik Sipil Universitas Indonesia <br/>
© <?php echo e(config('app.name')); ?>, 2014 - 2019 | Oleh Alumni Department Teknik Sipil UI <br/>
EMAIL : hello@seedsholarsip.org
<?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
