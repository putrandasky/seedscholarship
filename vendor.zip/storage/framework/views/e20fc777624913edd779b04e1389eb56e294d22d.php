<script src="<?php echo e(asset('js/admin/script-admin.js')); ?>"></script>
