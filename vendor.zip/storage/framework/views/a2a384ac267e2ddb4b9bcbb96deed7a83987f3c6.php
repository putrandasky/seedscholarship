<?php $__env->startComponent('mail::layout'); ?>
    
    <?php $__env->slot('header'); ?>
        <?php $__env->startComponent('mail::header', ['url' => config('app.url')]); ?>
            <!-- header here -->
            <img class="img-header" src="<?php echo e(config('app.url').'/images/Seedlogo2.png'); ?>">
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>

    
    <!-- Body here -->


Terima kasih <strong><?php echo e($data->name); ?></strong>,

Anda telah mendaftar sebagai :
    
<?php $__env->startComponent('mail::panel'); ?>
Donatur <strong><?php echo e($data->periods[0]->pivot->donation_category); ?></strong> untuk SEED Scholarship <strong>#<?php echo e($data->periods[0]->period); ?></strong> untuk tahun <strong><?php echo e($data->periods[0]->year); ?></strong>
<?php echo $__env->renderComponent(); ?>

Berikut detail data yang sudah anda registrasi ke kami
<?php $__env->startComponent('mail::panel'); ?>
Nama : <?php echo e($data->name); ?><br/>
Email : <?php echo e($data->email); ?><br/>
Phone : <?php echo e($data->phone); ?><br/>
Angkatan : <?php echo e($data->year); ?><br/>
Department : <?php echo e($data->awardeeDepartment->department); ?><br/>
Alamat : <?php echo e($data->address); ?><br/>
Kategori Donasi : <?php echo e($data->periods[0]->pivot->donation_category); ?><br/>
<?php if($data->periods[0]->pivot->amount != 0): ?>
Jumlah donasi : <?php echo e($data->periods[0]->pivot->amount); ?> / tahun<br/>
<?php endif; ?>
<?php if($data->periods[0]->pivot->donation_category == 'aktif'): ?>
Akan ditagihkan : <?php echo e($data->periods[0]->pivot->amount / 12); ?> / bulan<br/>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Kontribusi anda sangat berharga untuk Department Teknik Sipil UI.

Segera tim kami akan menghubungi anda untuk melakukan konfirmasi

Terimakasih,<br/>

<br/>
<img style="height:5%" src="<?php echo e(config('app.url').'/images/heart.png'); ?>">
<strong>seedscholarship.org</strong>






    
    <?php $__env->slot('footer'); ?>
        <?php $__env->startComponent('mail::footer'); ?>
            <!-- footer here -->

Anggit Cahyo S’08 : 085697274479 |
Janitra Hendra L’08 : 081290001300
<br/>
Bentuk kontribusi alumni Departemen Teknik Sipil Universitas Indonesia <br/>
© <?php echo e(config('app.name')); ?>, 2014 - 2019 | Oleh Alumni Department Teknik Sipil UI <br/>
EMAIL : hello@seedsholarsip.org
<?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
