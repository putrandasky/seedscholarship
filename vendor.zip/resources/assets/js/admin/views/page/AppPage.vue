<template>
</template>
<script>
    export default {
        name: 'AppPage',
        data: function () {
            return {
            }
        },
        created(){
        },
        methods:{
        },
    }
</script>
<style>
</style>
