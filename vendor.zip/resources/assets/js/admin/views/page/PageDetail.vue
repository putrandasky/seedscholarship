<template>
</template>
<script>
    export default {
        name: 'PageDetail',
        data: function () {
            return {
            }
        },
        created(){
        },
        methods:{
        },
    }
</script>
<style>
</style>
