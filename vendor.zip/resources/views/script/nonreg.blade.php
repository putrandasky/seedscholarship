<script src="{{ asset('js/nonreg/script-nonreg.js') }}"></script>
