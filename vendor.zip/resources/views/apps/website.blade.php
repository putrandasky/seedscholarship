@extends('layout.app')
@section('content')
<div id="app"></div>
@endsection

@section('script')
  @include('script.website')
@endsection
