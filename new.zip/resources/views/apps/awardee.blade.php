@extends('layout.awardee')
@section('content')
<div id="apps"></div>
@endsection

@section('script')
  @include('script.awardee')
@endsection
