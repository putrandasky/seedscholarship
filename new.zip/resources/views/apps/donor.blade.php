@extends('layout.donor')
@section('content')
<div id="apps"></div>
@endsection

@section('script')
  @include('script.donor')
@endsection
