<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Periodable extends Model
{
    //
}
