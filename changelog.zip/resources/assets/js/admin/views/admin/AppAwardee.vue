<template>
<div>
    this is user profile
</div>
</template>
<script>
    export default {
        name: 'UserProfile',
        data: function () {
            return {
            }
        },
        created(){
        },
        methods:{
        },
    }
</script>
<style>
</style>
