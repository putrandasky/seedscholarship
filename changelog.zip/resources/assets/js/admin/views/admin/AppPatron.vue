<template>
</template>
<script>
    export default {
        name: 'AppPatron',
        data: function () {
            return {
            }
        },
        created(){
        },
        methods:{
        },
    }
</script>
<style>
</style>
