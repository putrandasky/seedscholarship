<template>
<div>
  this is app vue
</div>
</template>
<script>
  export default {
    name: 'AuthApp',
    data: function () {
      return {
      }
    },
    beforeCreate: function() {
            document.body.className = 'nav-md';
        },
    created(){
    },
    methods:{
    },
  }
</script>
<style>
</style>