<?php

namespace App\Http\Controllers\Donor\Transaction;

use App;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CollectionOfficerController extends Controller
{
    //
}
