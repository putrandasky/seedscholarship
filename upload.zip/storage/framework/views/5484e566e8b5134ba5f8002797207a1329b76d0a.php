<script src="<?php echo e(asset('js/website/script.js')); ?>"></script>
