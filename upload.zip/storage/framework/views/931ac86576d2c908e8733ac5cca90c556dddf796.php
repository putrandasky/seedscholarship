<script src="<?php echo e(asset('js/nonreg/script-nonreg.js')); ?>"></script>
