<?php $__env->startComponent('mail::layout'); ?>
    
    <?php $__env->slot('header'); ?>
        <?php $__env->startComponent('mail::header', ['url' => config('app.url')]); ?>
            <!-- header here -->
            <img class="img-header" src="<?php echo e(asset('images/Seedlogo2.png')); ?>">
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>

    
    <!-- Body here -->


Hai <strong><?php echo e($data->name); ?></strong>,

Kamu telah mendaftar sebagai :
    
<?php $__env->startComponent('mail::panel'); ?>
Calon Awardee  untuk <strong><?php echo e($data->scholarships[0]->name); ?></strong> tahun <strong><?php echo e($data->scholarships[0]->year); ?></strong>
<?php echo $__env->renderComponent(); ?>

Berikut detail data yang sudah kamu registrasi ke kami
<?php $__env->startComponent('mail::panel'); ?>
Nama : <?php echo e($data->name); ?><br/>
Email : <?php echo e($data->email); ?><br/>
Phone : <?php echo e($data->phone); ?><br/>
Angkatan : <?php echo e($data->year); ?><br/>
Department : <?php echo e($data->awardeeDepartment->department); ?><br/>
<?php echo $__env->renderComponent(); ?>

Segera siapkan file berikut ini :
<?php $__env->startComponent('mail::panel'); ?>
<ol>
<li>CV / Riwayat Hidup : format bebas dengan informasi yang wajib ada yaitu: data diri, riwayat pendidikan, kemampuan bahasa, pengalaman kerja</li>
<li>Proposal Penelitian : dengan isi; latar belakang, tujuan, metodologi, RAB, referensi. (format: <a href="<?php echo e(config('app.url')."/files/BEASISWA PENELITIAN SEEDS 2019 - II - FORMAT PROPOSAL.docx"); ?>">download disini</a> )</li>
<li>Surat keterangan tidak menerima beasiswa riset lainnya (format: <a href="<?php echo e(config('app.url')."/files/BEASISWA PENELITIAN SEEDS 2019 - II - SK Tidak Menerima Beasiswa.docx"); ?>">download disini</a> )</li>
<li>SiakNG : Printout Halaman ringkasan dan riwayat</li>
</ol>
<?php echo $__env->renderComponent(); ?>

Selanjutnya upload file tersebut dengan menekan tombol dibawah ini
<?php $__env->startComponent('mail::button', ['url' => config('app.url')."/nonreg#/register/upload?id={$data->id}&email={$data->email}&scholarship_id={$data->scholarships[0]->id}&registration_code={$data->scholarships[0]->pivot->registration_code}"]); ?>
Upload Disini
<?php echo $__env->renderComponent(); ?>


Segera setelah kamu upload semua file yang dibutuhkan, tim kami akan menghubungi kamu untuk melakukan wawancara.

Terimakasih,<br/>

<br/>
<strong>seedscholarship.org</strong>
<img style="height:5%" src="<?php echo e(asset('images/heart.png')); ?>">


    
    <?php $__env->slot('footer'); ?>
        <?php $__env->startComponent('mail::footer'); ?>
            <!-- footer here -->
<strong>CONTACT : </strong>
Anggit Cahyo S’08 : 085697274479 |
Janitra Hendra L’08 : 081290001300
<br/>
Bentuk kontribusi alumni Departemen Teknik Sipil Universitas Indonesia <br/>
© <?php echo e(config('app.name')); ?>, 2014 - 2019 | Oleh Alumni Department Teknik Sipil UI <br/>
EMAIL : hello@seedsholarsip.org
<?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
