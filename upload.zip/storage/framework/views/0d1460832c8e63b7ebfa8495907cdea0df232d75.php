<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
  <title>Seedscholarship</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Seedscholarship - Bentuk kontribusi alumni Departement Teknik Sipil Universitas Indonesia">
  <meta name="author" content="Radityo Putra Paripurna">
  
  <meta property="og:title" content="Seedscholarship" />
   <meta property="og:url" content="https:/seedscholarship.org" />
  <meta property="og:description" content="Seedscholarship - Bentuk kontribusi alumni Departement Teknik Sipil Universitas Indonesia">
  <meta property="og:image" content="<?php echo e(asset('images/Seedlogo.png')); ?>">
  <meta property="og:type" content="website" />
  <!-- Favicon -->
  <link type="image/png" href="<?php echo e(asset('images/logo.png')); ?>" rel="icon">
  <!-- Fonts -->
  

  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  
  

</head>

<body>

  <?php echo $__env->yieldContent('content'); ?>

  <?php echo $__env->yieldContent('script'); ?>

</body>

</html>
