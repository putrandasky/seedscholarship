<script src="{{ asset('js/awardee/script-awardee.js') }}"></script>
