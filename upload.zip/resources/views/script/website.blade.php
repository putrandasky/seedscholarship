<script src="{{ asset('js/website/script.js') }}"></script>
