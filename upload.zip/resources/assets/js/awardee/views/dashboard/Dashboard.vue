<template>
<div>
    this is dashboard
</div>
</template>
<script>
    export default {
        name: 'Dashboard',
        data: function () {
            return {
            }
        },
        created(){
        },
        methods:{
        },
    }
</script>
<style>
</style>
