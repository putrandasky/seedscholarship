<template>
  <footer class="app-footer">
    <!-- <span><a href="https://alterfingers.com">CoreUI</a> &copy; 2018 creativeLabs.</span> -->
    <span class="ml-auto">Developed by <a href="https://alterfingers.com">Radityo Putra</a></span>
  </footer>
</template>
<script>
export default {
  name: 'c-footer'
}
</script>
