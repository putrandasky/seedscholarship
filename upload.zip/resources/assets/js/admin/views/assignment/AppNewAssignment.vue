<template>
</template>
<script>
    export default {
        name: 'AppNewAssignment',
        data: function () {
            return {
            }
        },
        created(){
        },
        methods:{
        },
    }
</script>
<style>
</style>
