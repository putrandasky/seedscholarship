<template>
<div class="mt-3">
  <b-alert show variant="info">Please select Scholarship period above</b-alert>
</div>
</template>
<script>
    export default {
        name: 'AppDonorDefault',
        data: function () {
            return {
            }
        },
        created(){
        },
        methods:{
        },
    }
</script>
<style>
</style>
