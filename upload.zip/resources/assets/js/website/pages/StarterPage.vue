<template>
    <div class="starter-page">
        <div class="section text-center">
            <h3>Create your next awesome website</h3>
        </div>
    </div>
</template>
<script>
  export default {
    name: 'starter'
  };
</script>
<style>
    .starter-page {
        min-height: calc(100vh - 95px);
    }
</style>
